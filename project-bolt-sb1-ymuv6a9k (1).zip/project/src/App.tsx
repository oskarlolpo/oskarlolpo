import React from 'react';
import { motion } from 'framer-motion';
import { Upload, Boxes, Zap, Users, ArrowRight } from 'lucide-react';
import { ModUploader } from './components/ModUploader';
import { Toaster } from 'react-hot-toast';

function App() {
  return (
    <div className="min-h-screen bg-background">
      <Toaster position="top-right" />
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h1 className="font-minecraft text-5xl md:text-7xl mb-6 bg-gradient-to-r from-purple-400 to-purple-600 text-transparent bg-clip-text">
            Сделайте Minecraft Быстрее
          </h1>
          <p className="text-gray-400 text-xl mb-8">
            Современный способ управления модами Minecraft
          </p>
          <button className="btn-primary text-lg">
            Начать <ArrowRight className="inline ml-2" size={20} />
          </button>
        </motion.div>
      </header>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card"
          >
            <Upload className="w-12 h-12 text-purple-500 mb-4" />
            <h3 className="font-minecraft text-xl mb-2">Анализ Модов</h3>
            <p className="text-gray-400">
              Загрузите моды и получите мгновенный анализ совместимости
            </p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card"
          >
            <Boxes className="w-12 h-12 text-purple-500 mb-4" />
            <h3 className="font-minecraft text-xl mb-2">Автоматические Зависимости</h3>
            <p className="text-gray-400">
              Автоматическое определение и установка необходимых библиотек
            </p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card"
          >
            <Zap className="w-12 h-12 text-purple-500 mb-4" />
            <h3 className="font-minecraft text-xl mb-2">Повышение Производительности</h3>
            <p className="text-gray-400">
              Оптимизация конфигурации модов для максимальной производительности
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mod Upload Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="card max-w-2xl mx-auto">
          <h2 className="font-minecraft text-2xl mb-6">Загрузите Ваши Моды</h2>
          <ModUploader />
        </div>
      </section>

      {/* Community Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="font-minecraft text-3xl mb-4">Присоединяйтесь к Сообществу</h2>
          <p className="text-gray-400">
            Общайтесь с другими игроками и делитесь своим опытом
          </p>
        </div>
        <div className="flex justify-center">
          <Users className="w-24 h-24 text-purple-500" />
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-purple-500/20 mt-16">
        <div className="container mx-auto px-4 py-8">
          <p className="text-center text-gray-400">
            © 2025 Minecraft Mod Manager. Все права защищены.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;