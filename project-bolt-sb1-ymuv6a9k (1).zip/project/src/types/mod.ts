export interface ModInfo {
  id: string;
  name: string;
  version: string;
  minecraftVersion: string;
  dependencies: string[];
  isCompatible: boolean;
  alternatives?: ModAlternative[];
}

export interface ModAlternative {
  id: string;
  name: string;
  version: string;
  downloads: number;
  rating: number;
  url: string;
}

export interface UploadedMod {
  file: File;
  analyzing: boolean;
  info?: ModInfo;
  error?: string;
}

export type ModLoader = 'fabric' | 'forge';
export type ArchiveFormat = 'zip' | 'mrpack';

export interface ModPackConfig {
  loader: ModLoader;
  minecraftVersion: string;
  format: ArchiveFormat;
}