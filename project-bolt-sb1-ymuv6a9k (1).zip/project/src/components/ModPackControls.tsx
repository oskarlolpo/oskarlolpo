import React from 'react';
import { motion } from 'framer-motion';
import type { ModLoader, ArchiveFormat, ModPackConfig } from '../types/mod';

interface ModPackControlsProps {
  config: ModPackConfig;
  onConfigChange: (config: ModPackConfig) => void;
  onCreatePack: () => void;
  disabled?: boolean;
}

const MINECRAFT_VERSIONS = ['1.20.4', '1.20.2', '1.20.1', '1.19.4', '1.19.2', '1.18.2'];
const LOADERS: { value: ModLoader; label: string }[] = [
  { value: 'fabric', label: 'Fabric' },
  { value: 'forge', label: 'Forge' },
];
const FORMATS: { value: ArchiveFormat; label: string }[] = [
  { value: 'zip', label: 'Архив ZIP' },
  { value: 'mrpack', label: 'Формат MRPACK' },
];

export function ModPackControls({ config, onConfigChange, onCreatePack, disabled }: ModPackControlsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card p-6 mb-8"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Загрузчик
          </label>
          <select
            value={config.loader}
            onChange={(e) => onConfigChange({ ...config, loader: e.target.value as ModLoader })}
            className="w-full bg-gray-900 border border-purple-500/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500 transition-all"
            disabled={disabled}
          >
            {LOADERS.map((loader) => (
              <option key={loader.value} value={loader.value}>
                {loader.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Версия Minecraft
          </label>
          <select
            value={config.minecraftVersion}
            onChange={(e) => onConfigChange({ ...config, minecraftVersion: e.target.value })}
            className="w-full bg-gray-900 border border-purple-500/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500 transition-all"
            disabled={disabled}
          >
            {MINECRAFT_VERSIONS.map((version) => (
              <option key={version} value={version}>
                {version}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Формат архива
          </label>
          <select
            value={config.format}
            onChange={(e) => onConfigChange({ ...config, format: e.target.value as ArchiveFormat })}
            className="w-full bg-gray-900 border border-purple-500/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500 transition-all"
            disabled={disabled}
          >
            {FORMATS.map((format) => (
              <option key={format.value} value={format.value}>
                {format.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <button
        onClick={onCreatePack}
        disabled={disabled}
        className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Создать сборку под себя
      </button>
    </motion.div>
  );
}