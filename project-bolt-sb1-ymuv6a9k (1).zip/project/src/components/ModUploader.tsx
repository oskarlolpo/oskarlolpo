import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-hot-toast';
import type { UploadedMod, ModPackConfig } from '../types/mod';
import { analyzeMod } from '../services/modAnalyzer';
import { ModPackControls } from './ModPackControls';
import { createModPack, downloadModPack } from '../services/modPacker';

export function ModUploader() {
  const [mods, setMods] = useState<UploadedMod[]>([]);
  const [isCreatingPack, setIsCreatingPack] = useState(false);
  const [packConfig, setPackConfig] = useState<ModPackConfig>({
    loader: 'fabric',
    minecraftVersion: '1.20.4',
    format: 'zip'
  });

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const newMods = acceptedFiles.map(file => ({
      file,
      analyzing: true
    }));

    setMods(prev => [...prev, ...newMods]);

    for (const mod of newMods) {
      try {
        const info = await analyzeMod(mod.file);
        setMods(prev => 
          prev.map(m => 
            m.file === mod.file 
              ? { ...m, analyzing: false, info } 
              : m
          )
        );
        toast.success(`Мод ${mod.file.name} успешно проанализирован`);
      } catch (error) {
        setMods(prev => 
          prev.map(m => 
            m.file === mod.file 
              ? { ...m, analyzing: false, error: (error as Error).message } 
              : m
          )
        );
        toast.error(`Ошибка анализа мода ${mod.file.name}`);
      }
    }
  }, []);

  const handleCreatePack = async () => {
    if (mods.length === 0) {
      toast.error('Добавьте хотя бы один мод для создания сборки');
      return;
    }

    try {
      setIsCreatingPack(true);
      const blob = await createModPack(mods, packConfig);
      downloadModPack(blob, packConfig);
      toast.success('Сборка успешно создана!');
    } catch (error) {
      toast.error('Ошибка при создании сборки');
      console.error(error);
    } finally {
      setIsCreatingPack(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/java-archive': ['.jar']
    }
  });

  return (
    <div className="w-full">
      <ModPackControls
        config={packConfig}
        onConfigChange={setPackConfig}
        onCreatePack={handleCreatePack}
        disabled={isCreatingPack || mods.length === 0}
      />

      <div
        {...getRootProps()}
        className={`border-2 border-dashed border-purple-500/30 rounded-lg p-8 text-center transition-colors
          ${isDragActive ? 'bg-purple-500/10' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="w-16 h-16 text-purple-500 mx-auto mb-4" />
        <p className="text-gray-400 mb-4">
          Перетащите .jar файлы сюда или нажмите для выбора
        </p>
        <button className="btn-primary">
          Выбрать Файлы
        </button>
      </div>

      <AnimatePresence>
        {mods.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mt-8 space-y-4"
          >
            {mods.map((mod, index) => (
              <div
                key={mod.file.name + index}
                className="card flex items-center justify-between p-4"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-minecraft text-lg">{mod.file.name}</h3>
                    {mod.analyzing ? (
                      <Loader2 className="w-5 h-5 text-purple-500 animate-spin" />
                    ) : mod.error ? (
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    )}
                  </div>
                  
                  {mod.info && (
                    <div className="mt-2 space-y-2">
                      <p className="text-gray-400 text-sm">
                        Версия: {mod.info.version} | MC: {mod.info.minecraftVersion}
                      </p>
                      {mod.info.alternatives && mod.info.alternatives.length > 0 && (
                        <div className="mt-2">
                          <p className="text-sm text-purple-400">Альтернативные моды:</p>
                          <ul className="mt-1 space-y-1">
                            {mod.info.alternatives.slice(0, 3).map((alt, idx) => (
                              <li key={idx} className="text-sm text-gray-400">
                                {alt.name} v{alt.version} от {alt.author}
                                <span className="ml-2 text-purple-400">
                                  {new Intl.NumberFormat('ru-RU').format(alt.downloads)} загрузок
                                </span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {mod.error && (
                    <p className="text-red-500 text-sm mt-2">{mod.error}</p>
                  )}
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}