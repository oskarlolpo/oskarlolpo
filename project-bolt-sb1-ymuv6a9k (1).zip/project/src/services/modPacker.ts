import JSZip from 'jszip';
import type { ModPackConfig, UploadedMod } from '../types/mod';

export async function createModPack(mods: UploadedMod[], config: ModPackConfig): Promise<Blob> {
  const zip = new JSZip();
  
  // Add manifest file
  const manifest = {
    minecraftVersion: config.minecraftVersion,
    loader: config.loader,
    mods: mods.map(mod => ({
      name: mod.info?.name,
      version: mod.info?.version,
      file: mod.file.name
    }))
  };
  
  zip.file('manifest.json', JSON.stringify(manifest, null, 2));
  
  // Add mods
  const modsFolder = zip.folder('mods');
  if (modsFolder) {
    for (const mod of mods) {
      if (!mod.error && mod.file) {
        modsFolder.file(mod.file.name, mod.file);
      }
    }
  }
  
  // Generate the zip file
  return await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: {
      level: 9
    }
  });
}

export function downloadModPack(blob: Blob, config: ModPackConfig) {
  const fileName = `minecraft-${config.minecraftVersion}-${config.loader}-mods.${config.format}`;
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}