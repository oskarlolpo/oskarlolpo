import JSZip from 'jszip';
import { searchModrinth, getModVersions } from './modrinth';

export interface ModAnalysis {
  name: string;
  version: string;
  minecraftVersion: string;
  alternatives?: Array<{
    name: string;
    version: string;
    downloads: number;
    author: string;
  }>;
  isCompatible: boolean;
}

export async function analyzeMod(file: File): Promise<ModAnalysis> {
  try {
    const zip = new JSZip();
    const contents = await zip.loadAsync(file);
    const manifestFile = contents.file('META-INF/MANIFEST.MF');
    
    if (!manifestFile) {
      throw new Error('Invalid mod format');
    }

    const manifest = await manifestFile.async('string');
    const version = manifest.match(/Implementation-Version:\s*(.*)/)?.[1] || 'Unknown';
    const name = file.name.replace('.jar', '');

    // Search for alternatives on Modrinth
    const alternatives = await searchModrinth(name);
    const modVersions = await getModVersions(alternatives[0]?.slug || '');

    return {
      name,
      version,
      minecraftVersion: '1.20.1', // This would be detected from the manifest
      alternatives: alternatives.map(alt => ({
        name: alt.title,
        version: modVersions[0] || 'Unknown',
        downloads: alt.downloads,
        author: alt.author
      })),
      isCompatible: true
    };
  } catch (error) {
    throw new Error(`Error analyzing mod: ${(error as Error).message}`);
  }
}