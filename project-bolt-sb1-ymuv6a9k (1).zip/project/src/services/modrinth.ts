import axios from 'axios';

const MODRINTH_API = 'https://api.modrinth.com/v2';

export interface ModrinthSearchResult {
  slug: string;
  title: string;
  description: string;
  downloads: number;
  versions: string[];
  author: string;
  client_side: string;
  server_side: string;
}

export async function searchModrinth(query: string): Promise<ModrinthSearchResult[]> {
  try {
    const response = await axios.get(`${MODRINTH_API}/search`, {
      params: {
        query,
        limit: 5,
        facets: [["project_type:mod"], ["versions:1.20.1"]]
      }
    });
    
    return response.data.hits.map((hit: any) => ({
      slug: hit.slug,
      title: hit.title,
      description: hit.description,
      downloads: hit.downloads,
      versions: hit.versions,
      author: hit.author,
      client_side: hit.client_side,
      server_side: hit.server_side
    }));
  } catch (error) {
    console.error('Error searching Modrinth:', error);
    return [];
  }
}

export async function getModVersions(slug: string): Promise<string[]> {
  try {
    const response = await axios.get(`${MODRINTH_API}/project/${slug}/version`);
    return response.data.map((version: any) => version.version_number);
  } catch (error) {
    console.error('Error fetching mod versions:', error);
    return [];
  }
}